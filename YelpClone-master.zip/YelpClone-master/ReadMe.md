collaborative YelpClone using RecyclerView and RESTful apis
